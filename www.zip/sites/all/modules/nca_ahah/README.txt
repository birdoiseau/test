INFORMATION FOR DEVELOPERS

This module provides the include file nca_ahah.inc, which contains some fairly generic
functions that allow you to "dynamically" extend a form with additional fields without
actually having to understand the gory details of the Drupal #ahah form API.
 
Usage:

1. Make up your mind about what the dynamically added items should be called.
   For example: "nca_ahah_order_item". This will be used to name form elements,
   related functions etc.

2. In menu_hook of your module, define a callback using the prefix path nca/ahah_js
   and the item name from step 1 as a suffix, like so:
      $items['nca_ahah/nca_ahah_order_item'] = array(
       'title' => 'Javascript Order Item Form',
       'page callback' => 'nca_ahah_callback',
       'page arguments' => array('nca_ahah_order_item'),
       'access arguments' => array('access content'),
       'type' => MENU_CALLBACK,
      );

3. Implement a function that actually creates the form fields representing an item.
   This function must be named /item name/_form. It will be invoked once for each
   already existing item (with field values already entered by the user) and for
   newly added items (without any field values).
      /**
       * @param $i      the item's position within the wrapper element (0..n-1)
       * @param $item   an array with current values that have been entered by
       *                the user (if any)
       */
      function nca_ahah_order_item_form(&$item_form, $i, $item) {
        // Your job is to define fields as if you were creating a normal form, e.g.
        // $item_form['some_field'] = array(/* insert field definition here */);
        // This function has no return value.
      }

4. Implement a function named theme_/item_name/($item_form). This function must return
   HTML code for each $form_item passed in. The simplest implementation would be:

     function theme_nca_ahah_order_item($item_form) { return drupal_render($item_form); }

   Don't forget to register your theme function using hook_theme, like so:

     function nca_theme() {
       return array('nca_ahah_order_item' => array('arguments' => array('form' => NULL));
     }

5. Implement the usual form submit and validate handler for the master form.
   However, keep in mind that these handlers will be called not only upon
   the final form submission, but also whenever the user pushes the button
   to add new items. You probably should distinguish between these two cases
   and suppress validation/submission processing.

6. In your master form definition, invoke the following function to add
   the wrapper element:
      nca_ahah_wrapper($form, $form_state, 'nca_ahah_order_item');

7. To avoid problems with the normal final form submission being
   directed to the ahah callback, you must also set #action in your
   master form definition explicitly, like so:
      $form['#action'] = url('nca_ahah/order'); 
