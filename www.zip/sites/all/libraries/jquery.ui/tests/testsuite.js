$(function() {

$('body').prepend(
	'<h1 id="header">' + document.title + '</h1>' +
	'<h2 id="banner"></h2>' +
	'<h2 id="userAgent"></h2>' +
	'<ol id="tests"></ol>'
);

});
